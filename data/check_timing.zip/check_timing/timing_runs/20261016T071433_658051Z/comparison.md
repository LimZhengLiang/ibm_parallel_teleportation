# Hardware-backed timing comparison

8 separate acquisitions per rank, three circuits per acquisition; rank 1 then rank 58.
All numbers below are NEW hardware compiler schedule durations, averaged over 8 jobs per rank.
No synthetic values or local scheduling durations are substituted.

| Effect | Rank 1 | Rank 58 |
|---|---|---|
| Classical post-processing versus feed-forward (sequential for both) | 21.256 us versus 23.924 us | 23.260 us versus 25.348 us |
| Additional parallelisation (sequential to parallel classical) | 21.256 us -> 14.500 us | 23.260 us -> 16.240 us |

## Interpretation

The metric is max(T0 + Duration) times the saved hardware backend.dt, with all trace channels and reported initialization/finalization included. It is not CPU time, queue time, billed QPU time or a shot-by-shot latency measurement. The older synthetic preparation-prefix values are a DIFFERENT timing scope and must not be mixed with this table.

Within each rank the two sequential variants share their routed native backbone; the classical variant removes only conditional correction blocks before rescheduling. The parallel variant starts from the same logical-to-physical layout but may use different routing and cancellations. Its saving is therefore an end-to-end implementation benefit, not a pure decomposition into scheduler-only and gate-only contributions.

No DD, gate twirling, measurement twirling or M3 calibration jobs are used. Only the selected analysis basis is acquired; these jobs do not measure entanglement fidelity.

Identical timings across trials are expected for frozen circuits and deterministic compiler schedules. These repetitions do not measure shot-by-shot latency variance. Negative savings, if observed, are retained rather than concealed.

Timing format and units: https://quantum.cloud.ibm.com/docs/en/guides/qiskit-runtime-circuit-timing
